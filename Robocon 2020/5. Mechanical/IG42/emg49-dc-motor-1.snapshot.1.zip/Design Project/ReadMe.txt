Hello dear

If you Have this motor Please Modify my model to Improve it.

Usable for EMG49/PG 420 or IG42 dc motors
